import React from 'react';
import { connect } from 'react-redux';
import { ActionCreators } from '../src/Store/Actions';
import Navigator from './Navigator';

class App extends React.Component {
  componentDidMount() {
    const res = this.props.registeredProfiles;
    this.props.dispatch(ActionCreators.registeredProfiles(res));
  }
  render() {
    return (
      <div>
        <Navigator />
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    profile: state.user.profile,
    registeredProfiles: state.user.registeredProfiles
  }
}

export default connect(mapStateToProps)(App);
