import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from "react-router-dom";
import { ActionCreators } from '../../Store/Actions';

let users =[];
export class Confirmation extends Component {
    componentDidMount() {
        const res = this.props.registeredProfiles;
        this.props.dispatch(ActionCreators.registeredProfiles(res));
        if (this.props.profile.UserName !== "") {
          users.push(this.props.profile);
          const userlist = JSON.parse(window.localStorage.getItem("users"));
          if(userlist)
          {
           users = [...users, ...userlist];
          }
          window.localStorage.setItem('users', JSON.stringify(users));
        }
      }
      gotoLogin = (event)=>{
        const res = this.props.registeredProfiles;
        this.props.dispatch(ActionCreators.registeredProfiles(res));
        this.props.history.push("/login");
      }
    render() {
        return (
            <div >
                <h1>Registration successful!</h1>
                <div>
                    Please login here : <a href="#" onClick={(e)=>this.gotoLogin()}>Login</a>
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        profile: state.user.profile,
        registeredProfiles: state.user.registeredProfiles
    }
}

export default connect(mapStateToProps)(withRouter(Confirmation));
