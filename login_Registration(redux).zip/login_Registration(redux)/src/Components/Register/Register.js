import React, { Component } from 'react';
import { connect } from 'react-redux';
import { ActionCreators } from '../../Store/Actions';

export class Register extends Component {
    constructor(props) {
        super(props);
        this.state = {
            user: {
                UserName: "",
                password: "",
                age: "",
                emailid: "",
                phone: ""
            },
            submitted: false,
            errors: {
                user: {
                    UserName: 'Enter UserName',
                    phone: 'Invalid Number',
                    emailid: 'Email is not valid!',
                    age: "Enter age",
                    password: "Enter password"
                }
            },
        }
    }
    isValidEmail = (value) => {
        return !(value && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,64}$/i.test(value))
    }
    formatPhoneNumber = (value) => {
        if (!value) return
        const currentValue = value.replace(/[^\d]/g, '');
        const mobileNoLength = currentValue.length;
        if (mobileNoLength >= 7) {
            if (mobileNoLength < 4) return currentValue;
            if (mobileNoLength < 7) return `(${currentValue.slice(0, 3)}) ${currentValue.slice(3)}`;
            return `(${currentValue.slice(0, 3)}) ${currentValue.slice(3, 6)}-${currentValue.slice(6, 10)}`;
        } else {
            return currentValue;
        }
    }
    inputChange = (event) => {
        let telphone = '';
        const { name, value } = event.target;
        let user = this.state.user;
        if (name === 'telephone') {
            telphone = this.formatPhoneNumber(value);
            user[name] = telphone;
        } else {
            user[name] = value;
        }
        this.setState({ user:user });
        this.validationErrorMessage(event);
    }
    validationErrorMessage = (event) => {
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'UserName':
                errors.user.UserName = value.length < 1 ? 'Enter Name' : '';
                break;
            case 'emailid':
                errors.user.emailid = this.isValidEmail(value) ? '' : 'Email is not valid!';
                break;
            case 'phone':
                errors.user.phone = value.length < 1 && value.length > 10 ? 'Enter valid telephone number' : '';
                break;
            case 'age':
                errors.user.age = value.length < 1 ? 'enter age' : '';
                break;
            case 'password':
                errors.user.password = value.length < 1 ? 'enter password' : '';
                break;
            default:
                break;
        }

        this.setState({ errors });
    }
    validateForm = (errors) => {
        let valid = true;
        Object.entries(errors.user).forEach(item => {
            console.log(item)
            item && item[1].length > 0 && (valid = false)
        })
        return valid;
    }
    submitForm = () => {
        this.setState({ submitted: true });
        let register = true;
        if (this.validateForm(this.state.errors)) {
            console.info('Valid Form');
            const users = JSON.parse(window.localStorage.getItem("users"));
            if (users) {
                users.map(ele => {
                    if (ele.emailid === this.state.user.emailid) {
                        register = false;
                    }
                })
            }
            if (register) {
                this.props.dispatch(ActionCreators.addProfile(this.state.user));
                let arr = this.props.registeredProfiles ? this.props.registeredProfiles : [];
                arr.push(this.state.user);
                this.props.dispatch(ActionCreators.registeredProfiles(arr));
                this.props.history.push('/confirmation');
            }
            else {
                alert("Email id Already Exists");
            }
        }
        else {
            console.log('Invalid Form')
        }
    }
    render() {
        const { UserName, password, age, emailid, phone } = this.state.user;
        const { submitted } = this.state;
        return (
            <React.Fragment>
                <h1>Register Page</h1>
                <label>Name</label>
                <input type="text" value={UserName} name="UserName" onChange={(e) => { this.inputChange(e) }} placeholder="Enter Name" />
                {submitted && this.state.errors.user.UserName.length > 0 && <span >{this.state.errors.user.UserName}</span>}<br />
                <label>Password</label>
                <input type="password" value={password} name="password" onChange={(e) => { this.inputChange(e) }} placeholder="Enter password" />
                {submitted && this.state.errors.user.password.length > 0 && <span >{this.state.errors.user.password}</span>}<br />
                <label>Age</label>
                <input type="text" value={age} name="age" onChange={(e) => { this.inputChange(e) }} placeholder="Enter Age" />
                {submitted && this.state.errors.user.age.length > 0 && <span >{this.state.errors.user.age}</span>}<br />
                <label >Email</label>
                <input type="text" value={emailid} name="emailid" onChange={(e) => { this.inputChange(e) }} placeholder="Enter email id" />
                {submitted && this.state.errors.user.emailid.length > 0 && <span >{this.state.errors.user.emailid}</span>}<br />
                <label >Phone Number</label>
                <input type="text" value={phone} name="phone" onChange={(e) => { this.inputChange(e) }} placeholder="Enter phone number" />
                {submitted && this.state.errors.user.phone.length > 0 && <span >{this.state.errors.user.phone}</span>}<br />
                <button type="button" onClick={this.submitForm}>Submit</button>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        profile: state.user.profile,
        registeredProfiles: state.user.registeredProfiles
    }
}
export default connect(mapStateToProps)(Register);