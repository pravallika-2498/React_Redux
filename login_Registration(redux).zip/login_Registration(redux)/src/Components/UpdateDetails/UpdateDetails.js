import React, { Component } from 'react';
import { withRouter } from "react-router-dom";
import { connect } from 'react-redux';
import { ActionCreators } from '../../Store/Actions';


export class UpdateDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: {
        UserName: "",
        password: "",
        age: "",
        emailid: "",
        phone: ""
      }
    }
  }
  componentDidMount() {
    //const users = JSON.parse(window.localStorage.getItem("users"));
    this.setState({ user: this.props.profile });
  }
  // componentDidUpdate(){
  //   if (this.props.updateDetailsStatus === true) {
  //     users.push(this.state.user);
  //     let userlist = JSON.parse(window.localStorage.getItem("users"));
  //     if(userlist)
  //     {
  //       userlist = userlist.filter(ele => ele.UserName !== this.state.user.UserName);
  //       console.log("userlist in update comp:", userlist);
  //      users = [...users, ...userlist];
  //     }
  //     window.localStorage.setItem('users', JSON.stringify(users));

  //   }
  // }
  inputChange = (event) => {
    const { name, value } = event.target;
    const user = this.state.user;
    user[name] = value;
    this.setState({ user });
  }

  updateUser = () => {
    let users = [];
    if (this.state.user.userName !== "" && this.state.user.password !== "" && this.state.user.emailid !== "") {
      this.props.dispatch(ActionCreators.updateProfile(this.state.user));
      users.push(this.state.user);
      let userlist = JSON.parse(window.localStorage.getItem("users"));
      if (userlist) {
        userlist = userlist.filter(ele => ele.emailid !== this.state.user.emailid);
        console.log("userlist in update comp:", userlist);
        users = [...users, ...userlist];
      }
      window.localStorage.setItem('users', JSON.stringify(users));
      this.props.history.push("/displaydetails");
    }
    else{
      alert("Name, password and email fields cannot be empty!");
    }
  }

  deleteUser = (event) => {
    const { name } = event.target;
    const user = this.state.user;
    user[name] = "";
    this.setState({ user });
    this.props.dispatch(ActionCreators.updateProfile(this.state.user));
    this.props.history.push("/displaydetails");
  }

  render() {
    return (
      <div >
        <h1>Update User Details</h1>
        <div>
          Name: <input type="text" name="UserName" onChange={(e) => { this.inputChange(e) }} value={this.state.user.UserName} /> <br />
          Password: <input type="text" name="password" onChange={(e) => { this.inputChange(e) }} value={this.state.user.password} /> <br />
          Age: <input type="text" name="age" onChange={(e) => { this.inputChange(e) }} value={this.state.user.age} /> <br />
          Email: <input type="text" name="emailid" onChange={(e) => { this.inputChange(e) }} value={this.state.user.emailid} /> <br />
          Phone: <input type="text" name="phone" onChange={(e) => { this.inputChange(e) }} value={this.state.user.phone} /> <br />
          <button type="submit" onClick={this.updateUser}>Update</button>
        </div>
      </div>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    profile: state.user.profile,
    updateDetailsStatus: state.user.updateDetailsStatus
  }
}

export default connect(mapStateToProps)(withRouter(UpdateDetails));
