import DisplayDetails from './DisplayDetails';

export default DisplayDetails;
