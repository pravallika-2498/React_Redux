import React, { Component } from 'react';
import { withRouter } from "react-router-dom";
import { connect } from 'react-redux';
import { ActionCreators } from '../../Store/Actions';
import { UpdateDetails } from '../UpdateDetails/UpdateDetails';

export class DisplayDetails extends Component {
    constructor(props) {
        super(props);

    }

    updateUser = (e) => {
        e.preventDefault();
        const email = e.target.id;
        // this.props.dispatch(ActionCreators.updateDetailsStatus(true));
        const data= this.props.registeredProfiles;
        data.map(ele => {
            if (ele.emailid === email) {
                this.props.dispatch(ActionCreators.updateProfile(ele));
            }
        });
       
        this.props.history.push("/updatedetails");
    }
    deleteUser = (e) => {
        e.preventDefault();
        const email = e.target.id;
        // this.props.dispatch(ActionCreators.updateDetailsStatus(true));
        let data= this.props.registeredProfiles;
        data.filter(ele => {
            if (ele.emailid === email) {
                data=data.filter(ele => ele.emailid !== email);
                
            }
        });
        this.props.dispatch(ActionCreators.registeredProfiles(data));
        
        
      }
      logout=(e)=>{
        e.preventDefault();
        const res = this.props.registeredProfiles;
        this.props.dispatch(ActionCreators.registeredProfiles(res));
        this.props.history.push("/login"); 
      }
    render() {
       
        const userslist = this.props.registeredProfiles;
        return (

            <div >
                <h1>Display User Details</h1>
                <table>
                    <tr>
                        <th>Name</th>
                        <th>Password</th>
                        <th>Age</th>
                        <th>Email</th>
                        <th>Phone</th>
                    </tr>
                    {userslist.map(
                        (item) => {
                            return <tr>
                                <td>{item.UserName}</td>
                                <td>{item.password}</td>
                                <td>{item.age}</td>
                                <td>{item.emailid}</td>
                                <td>{item.phone}</td>
                                <td>{<button id={item.emailid} type="submit" onClick={(e)=>this.updateUser(e)}>Update</button>}</td>
                                <td>{<button id={item.emailid} type="submit" onClick={(e)=>this.deleteUser(e)}>Delete</button>}</td>
                            </tr>
                            
                        })
                    }
                </table>
                <button type="submit" onClick={(e)=>this.logout(e)}>Logout</button>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        profile: state.user.profile,
        registeredProfiles: state.user.registeredProfiles
    }
}

export default connect(mapStateToProps)(withRouter(DisplayDetails));
