import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Redirect, Switch } from 'react-router-dom';
import Login from './Components/Login';
import Register from './Components/Register';
import Confirmation from './Components/Confirmation';
import UpdateDetails from './Components/UpdateDetails';
import DisplayDetails from './Components/DisplayDetails';
import { connect } from 'react-redux';

export const getStore = (name) => {
  if (!name) return
  return JSON.parse(window.localStorage.getItem(name))
}

function AuthenticatedRoute({ component: Component, ...rest }) {
  return (
    <Route
      {...rest}
      render={(props) => getStore('users') ? <Component {...props} />
        : <Redirect to={{ pathname: '/login', state: { from: props.location } }} />}
    />
  )
}
class Navigator extends Component {

  render() {
    return (
      <Router>
        <Switch>
          <Route exact path="/login" component={Login} />
          <Route exact path="/register" component={Register} />
          <Route exact path="/confirmation" component={Confirmation} />
          <Route exact path='/updatedetails' component={UpdateDetails} />
          <AuthenticatedRoute exact  path="/displaydetails" component={DisplayDetails} />
          <Route path='*' component={Login} />
        </Switch>
      </Router>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    profile: state.user.updateDetailsStatus
  }
}

export default connect(mapStateToProps)(Navigator);