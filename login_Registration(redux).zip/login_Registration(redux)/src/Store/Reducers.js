const initialState = {
  profile:
  {
    UserName: '',
    phone: '',
    age: '',
    emailid: '',
    password: ''
  },
  formSubmitted: false,
  updateDetailsStatus: false,
  registeredProfiles: ""
}

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case "LOGIN":
      console.log('login here:', action.payload.user)
      return {
        ...state,
        profile: action.payload.user,
        formSubmitted: false
      }
    case "ADD_USER":
      return {
        ...state,
        profile: action.payload.user,
        formSubmitted: false
      }
    case "UPDATE_USER":
      return {
        ...state,
        profile: action.payload.user,
        formSubmitted: false
      }
    case "FORM_SUBMITION_STATUS":
      return {
        ...state,
        formSubmitted: action.payload.status
      }

    case "UPDATE_DETAILS_STATUS":
      return {
        ...state,
        updateDetailsStatus: action.payload.status
      }

    case "REGISTERED_PROFILES":
      return {
        ...state,
        registeredProfiles:  action.payload.registeredProfiles
      }
    default:
      return state;
  }
}

export default reducer;